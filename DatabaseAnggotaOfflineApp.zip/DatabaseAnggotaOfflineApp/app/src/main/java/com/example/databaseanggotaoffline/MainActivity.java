package com.example.databaseanggotaoffline;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, results; EditText search; String[] headers;
 @Override public void onCreate(Bundle b){super.onCreate(b); build(); loadCsv();}
 TextView tv(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(18,10,18,10);if(bold)t.setTypeface(null,1);return t;}
 void build(){ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,24);root.setBackgroundColor(Color.WHITE);
  root.addView(tv("DATABASE ANGGOTA",24,true));root.addView(tv("Pencarian offline • 581 data • 18 kolom",14,false));
  search=new EditText(this);search.setHint("Ketik nama anggota");search.setSingleLine(true);root.addView(search,new LinearLayout.LayoutParams(-1,-2));
  Button btn=new Button(this);btn.setText("CARI");root.addView(btn,new LinearLayout.LayoutParams(-1,-2));
  TextView info=tv("Masukkan nama lengkap atau sebagian nama.",13,false);root.addView(info);
  results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);sv.addView(root);setContentView(sv);
  btn.setOnClickListener(v->doSearch());search.setOnEditorActionListener((v,a,e)->{doSearch();return true;}); }
 ArrayList<String[]> rows=new ArrayList<>();
 void loadCsv(){try(BufferedReader br=new BufferedReader(new InputStreamReader(getAssets().open("database_anggota_offline.csv")))){String line;boolean first=true;while((line=br.readLine())!=null){String[] p=parse(line);if(first){headers=p;first=false;}else if(p.length>2)rows.add(p);}}catch(Exception e){Toast.makeText(this,"Database gagal dibuka",Toast.LENGTH_LONG).show();}}
 String[] parse(String s){ArrayList<String> a=new ArrayList<>();StringBuilder x=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='\"'){q=!q;}else if(c==','&&!q){a.add(x.toString());x.setLength(0);}else x.append(c);}a.add(x.toString());return a.toArray(new String[0]);}
 void doSearch(){String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);results.removeAllViews();if(q.isEmpty()){results.addView(tv("Silakan masukkan nama.",15,true));return;}int n=0;for(String[] r:rows){if(r.length>2&&r[2].toLowerCase(Locale.ROOT).contains(q)){n++;addCard(r,n);}}if(n==0)results.addView(tv("Data tidak ditemukan.",16,true));else results.addView(tv("Ditemukan: "+n+" data",14,true),0);}
 void addCard(String[] r,int no){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(8,12,8,12);card.setBackgroundColor(Color.rgb(245,245,245));TextView title=tv(no+". "+r[2],19,true);card.addView(title);for(int i=0;i<headers.length&&i<r.length;i++){String val=r[i];if(val==null)val="";if(val.endsWith(" 00:00:00"))val=val.substring(0,val.length()-9);card.addView(tv(headers[i]+": "+val,14,false));}results.addView(card,new LinearLayout.LayoutParams(-1,-2));Space sp=new Space(this);results.addView(sp,new LinearLayout.LayoutParams(1,12));}
}
