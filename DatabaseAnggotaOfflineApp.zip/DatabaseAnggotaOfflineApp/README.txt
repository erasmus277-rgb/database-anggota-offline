DATABASE ANGGOTA OFFLINE

Aplikasi Android offline untuk mencari data anggota berdasarkan NAMA.
Database: database_anggota_offline.csv
Fitur: kolom nama, tombol CARI, pencarian sebagian nama, hasil semua data yang cocok.

Cara membuat APK:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle selesai.
3. Build > Build APK(s).
4. APK debug berada di app/build/outputs/apk/debug/app-debug.apk

Catatan: proyek ini sengaja dibuat tanpa server/database online. CSV dibundel ke dalam aplikasi.
